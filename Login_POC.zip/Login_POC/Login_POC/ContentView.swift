//
//  ContentView.swift
//  Login_POC
//
//  Created by Khan, Salman16 on 17/04/24.
//

import SwiftUI

struct ContentView: View {
    
//    @State private var username: String = ""
//    @State private var password: String = ""
    @State private var isLoginButtonDisabled = false
    @ObservedObject private var viewModel = LoginViewModel()
    
    var body: some View {
        VStack {
            TextField("Username", text: $viewModel.username)
                .padding()
                .background(Color(.secondarySystemBackground))
                .cornerRadius(8.0)
                .padding(.horizontal)
            
            SecureField("Password", text: $viewModel.password)
                .padding()
                .background(Color(.secondarySystemBackground))
                .cornerRadius(8.0)
                .padding([.horizontal, .bottom])
            
            Button(action: {
                print("Username : \(viewModel.username) and Password: \(viewModel.password)")
                
                viewModel.login { result in
                    switch result {
                    case .success(let loginResponse):
                        print("Login successful Token: \(loginResponse.token)")
                    case .failure(let error):
                        viewModel.errorMessage = error.localizedDescription
                    }
                    
                }
            }) {
                Text("Login")
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(isLoginButtonDisabled ? Color.gray : Color.blue)
                    .cornerRadius(8.0)
                    .padding(.horizontal)
                    .opacity(isLoginButtonDisabled ? 0.5 : 1.0)
                    .disabled(isLoginButtonDisabled)
            }
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
