//
//  Login_POCApp.swift
//  Login_POC
//
//  Created by Khan, Salman16 on 17/04/24.
//

import SwiftUI

@main
struct Login_POCApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
