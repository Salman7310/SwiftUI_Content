//
//  LoginResponse.swift
//  Login_POC
//
//  Created by Khan, Salman16 on 17/04/24.
//

import Foundation

struct LoginResponse: Codable {
    var token: String
}
