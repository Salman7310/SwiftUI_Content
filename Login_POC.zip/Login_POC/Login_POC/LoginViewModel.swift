//
//  LoginModel.swift
//  Login_POC
//
//  Created by Khan, Salman16 on 17/04/24.
//

import SwiftUI
import Foundation

class LoginViewModel: ObservableObject {
    
    @Published var username = ""
    @Published var password = ""
    @Published var errorMessage = ""
    @Published var isLoading = false
    
    func login(completion: @escaping (Result<LoginResponse, Error>) -> Void) {
        
        guard let url = URL(string: "www.google.com") else {
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let requestBody = ["username": username, "password": password]
        guard let requestBodyData = try? JSONSerialization.data(withJSONObject: requestBody) else {
            return
        }
        request.httpBody = requestBodyData
        
        // Perform the request
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            guard let data = data, error == nil else {
                completion(.failure(NetworkError.requestFailed))
                return
            }
            
            do {
                let loginResponse = try JSONDecoder().decode(LoginResponse.self, from: data)
                completion(.success(loginResponse))
            } catch {
                completion(.failure(NetworkError.invalidResponse))
                return
            }
        }.resume()
    }
}

enum NetworkError: Error {
    case invalidURL
    case invalidRequestBody
    case requestFailed
    case invalidResponse
}
